
(function(){
  var doc=document.documentElement; doc.classList.add('js');
  var reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* starfields */
  document.querySelectorAll('.starfield').forEach(function(f){
    for(var i=0;i<46;i++){var s=document.createElement('i');var z=(Math.random()*4+2).toFixed(1);s.style.cssText='left:'+(Math.random()*100)+'%;top:'+(Math.random()*100)+'%;--s:'+z+'px;--d:'+(3+Math.random()*4).toFixed(1)+'s;animation-delay:-'+(Math.random()*5).toFixed(1)+'s';f.appendChild(s);}
  });

  /* reveal */
  var io='IntersectionObserver' in window && !reduce ? new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);}})},{rootMargin:'0px 0px -8% 0px'}) : null;
  function arm(scope){scope.querySelectorAll('.rv:not(.in)').forEach(function(el){io?io.observe(el):el.classList.add('in');});}

  /* router */
  var pages=['home','about','kids'];
  var header=document.getElementById('top');
  function route(){
    var h=(location.hash||'#home').slice(1), page=h, target=null;
    if(pages.indexOf(h)<0){
      var el=h&&document.getElementById(h); var pg=el&&el.closest('.page');
      if(pg){page=pg.dataset.page;target=el;} else page='home';
    }
    pages.forEach(function(p){document.getElementById('page-'+p).classList.toggle('on',p===page);});
    document.querySelectorAll('.nav a').forEach(function(a){
      var r=a.getAttribute('data-route'); var cur= target? (target.id===r) : (r===page);
      cur?a.setAttribute('aria-current','page'):a.removeAttribute('aria-current');
    });
    document.querySelectorAll('.tabbar a').forEach(function(a){var t=a.dataset.tab;var cur=target?(target.id===t||(t==='join'&&target.id==='kids-join')):(t===page);cur?a.setAttribute('aria-current','page'):a.removeAttribute('aria-current');});
    var titles={home:'Mrs. Marcela · School Adjustment Counselor',about:'About · Mrs. Marcela',kids:"Kids' Corner · Mrs. Marcela"};
    document.title=titles[page];
    document.body.classList.remove('menu-open');document.querySelector('.menu-btn').setAttribute('aria-expanded','false');
    arm(document.getElementById('page-'+page));
    if(target){
      var off=function(){return (window.innerWidth<=760?64:84)};
      setTimeout(function(){window.scrollTo({top:target.getBoundingClientRect().top+scrollY-off(),behavior:reduce?'auto':'smooth'});},30);
      setTimeout(function(){var d=target.getBoundingClientRect().top-off();if(Math.abs(d)>12)window.scrollTo({top:scrollY+d,behavior:'auto'});},1300);
    }
    else window.scrollTo(0,0);
  }
  window.addEventListener('hashchange',route); route();

  /* sign-up forms.
     FORM_ENDPOINT: paste a Formspree / Kit / Mailchimp-compatible endpoint here (e.g. https://formspree.io/f/xxxxxx).
     Left empty, the form opens the visitor's email app addressed to CONTACT_EMAIL. */
  var FORM_ENDPOINT='';
  var CONTACT_EMAIL='hello@mrsmarcela.com';
  var dbP=null;
  function getDb(){
    if(!dbP) dbP=(window.claude&&claude.use?Promise.all([claude.use('db'),claude.use('user')]):Promise.resolve([null,null])).catch(function(){return [null,null]});
    return dbP;
  }
  setTimeout(getDb,200);
  document.querySelectorAll('.signup').forEach(function(f){
    f.addEventListener('submit',function(e){
      e.preventDefault();
      var msg=f.querySelector('.form-msg'), em=f.querySelector('[name=email]');
      var data={name:f.name.value.trim().slice(0,80),email:em.value.trim().slice(0,160),role:f.role.value,lang:f.lang.value,source:f.dataset.source,createdAt:new Date().toISOString()};
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)){em.setAttribute('aria-invalid','true');msg.className='form-msg err';msg.textContent='Please enter a valid email address.';em.focus();return;}
      em.removeAttribute('aria-invalid');msg.className='form-msg';msg.textContent='Saving...';
      var btn=f.querySelector('button');btn.disabled=true;
      var timer=new Promise(function(r){setTimeout(function(){r([null,null])},10000)});
      var send = FORM_ENDPOINT ? fetch(FORM_ENDPOINT,{method:'POST',headers:{'Accept':'application/json','Content-Type':'application/json'},body:JSON.stringify(data)}).then(function(r){if(!r.ok)throw 0;})
        : Promise.race([getDb(),timer]).then(function(caps){
        var db=caps[0],user=caps[1];
        if(!db||!user) throw 0;
        return user.id().then(function(id){ if(!id) throw 0; return db.collection('signups').doc(id).set(data); });
      });
      send.then(function(){
        f.classList.add('done');msg.textContent='Thank you'+(data.name?', '+data.name:'')+'! You are on the list.';
      }).catch(function(){
        var body='Please add me to the Mrs. Marcela list.%0A%0AName: '+encodeURIComponent(data.name)+'%0AEmail: '+encodeURIComponent(data.email)+'%0AI am a: '+encodeURIComponent(data.role)+'%0ALanguage: '+encodeURIComponent(data.lang);
        location.href='mailto:'+CONTACT_EMAIL+'?subject='+encodeURIComponent('Join the list')+'&body='+body;
        f.classList.add('done');msg.textContent='Your email app is opening to finish signing up. Thank you!';
      }).finally(function(){btn.disabled=false;});
    });
  });


  /* hero language toggle */
  var HL={
    en:{h:'Every child has a world of possibilities.',t:"Let's open the door together.",lede:"I'm Marcela Laliberte, known at school as Mrs. Marcela. I'm a multilingual School Adjustment Counselor in Massachusetts, helping children, families and educators turn everyday moments into growth.",cta1:'Get free resources',cta2:'Explore services',f1:'15+ years with children and families',f3:'Licensed in Massachusetts'},
    es:{h:'Cada niño tiene un mundo de posibilidades.',t:'Abramos la puerta juntos.',lede:'Soy Marcela Laliberte, conocida en el colegio como Mrs. Marcela. Soy consejera escolar multilingüe (School Adjustment Counselor) en Massachusetts y acompaño a niños, familias y docentes a convertir los momentos de cada día en crecimiento.',cta1:'Recibe recursos gratis',cta2:'Ver servicios',f1:'Más de 15 años con niños y familias',f3:'Con licencia en Massachusetts'},
    pt:{h:'Toda criança tem um mundo de possibilidades.',t:'Vamos abrir a porta juntos.',lede:'Sou Marcela Laliberte, conhecida na escola como Mrs. Marcela. Sou conselheira escolar multilíngue (School Adjustment Counselor) em Massachusetts e ajudo crianças, famílias e educadores a transformar os momentos do dia a dia em crescimento.',cta1:'Receba recursos grátis',cta2:'Ver serviços',f1:'Mais de 15 anos com crianças e famílias',f3:'Licenciada em Massachusetts'}
  };
  var hh=document.getElementById('hero-h'),ht=document.getElementById('hero-t'),hero=document.querySelector('.hero');
  document.querySelectorAll('.lang button').forEach(function(b){b.addEventListener('click',function(){
    var l=b.dataset.lang,d=HL[l]; document.querySelectorAll('.lang button').forEach(function(x){x.setAttribute('aria-pressed',String(x===b))});
    hh.classList.add('swapping');ht.classList.add('swapping');
    setTimeout(function(){
      hh.textContent=d.h;ht.textContent=d.t;
      hero.querySelectorAll('[data-i18n]').forEach(function(el){el.textContent=d[el.dataset.i18n];});
      hero.lang=l;hh.classList.remove('swapping');ht.classList.remove('swapping');
    },reduce?0:250);
  })});

  /* audience tabs */
  var AUD={
    students:{ic:'#i-backpack',h:'For students',w:'Helping children understand their feelings, build skills and recognize their strengths.',c:'Get resources for kids',l:[['Social-emotional learning','Lessons and small groups on feelings, friendship, problem-solving and self-confidence.'],['Emotional regulation tools','Calm-down strategies children can use in class, at recess and at home.'],['Early support and prevention','Noticing small challenges early, before they grow into bigger ones.']]},
    educators:{ic:'#i-apple',h:'For educators',w:'Practical strategies that support the whole classroom, not just one moment.',c:'Get classroom ideas',l:[['Classroom consultation','Looking beyond behavior together to understand what a child is communicating.'],['Ready-to-use SEL materials','Visuals, scripts and activities that fit into a real school day.'],['Behavior support planning','Consistent, caring routines that help children feel safe and ready to learn.']]},
    families:{ic:'#i-house',h:'For families',w:'Strengthening connection, communication and growth at home.',c:'Get family resources',l:[['Family workshops','Practical sessions on emotions, routines and talking with children about big feelings.'],['Multilingual support','Conversations and materials in Spanish, English and Portuguese.'],['Home-school collaboration','Bridging school and home so children feel one steady circle of support.']]},
    schools:{ic:'#i-book',h:'For schools',w:'Professional development, training and materials for schools and counseling teams.',c:'Ask about a workshop',l:[['Trauma-informed classrooms','Understanding how experiences shape behavior, and what helps.'],['SEL through creativity','Using stories, crafts and visuals to teach emotional skills.'],['Supporting multilingual families','Culture, language and community as part of every child\'s support plan.']]}
  };
  var tabs=[].slice.call(document.querySelectorAll('.aud-tabs [role=tab]')), panel=document.getElementById('aud-panel');
  function pick(t,focus){
    var k=t.dataset.aud,d=AUD[k];
    tabs.forEach(function(x){var on=x===t;x.setAttribute('aria-selected',String(on));x.tabIndex=on?0:-1;});
    if(focus)t.focus();
    panel.setAttribute('aria-labelledby',t.id);panel.classList.add('swapping');
    setTimeout(function(){
      panel.dataset.aud=k;
      document.getElementById('aud-ic').setAttribute('href',d.ic);
      document.getElementById('aud-h').textContent=d.h;document.getElementById('aud-who').textContent=d.w;
      document.getElementById('aud-cta').firstChild.textContent=d.c+' ';
      var ul=document.getElementById('aud-list');ul.innerHTML='';
      d.l.forEach(function(it){var li=document.createElement('li');li.innerHTML='<svg aria-hidden="true"><use href="#i-star"/></svg><div><b></b><span></span></div>';li.querySelector('b').textContent=it[0];li.querySelector('span').textContent=it[1];ul.appendChild(li);});
      panel.classList.remove('swapping');
    },reduce?0:220);
  }
  tabs.forEach(function(t,i){
    t.addEventListener('click',function(){pick(t)});
    t.addEventListener('keydown',function(e){var n=null;if(e.key==='ArrowRight')n=tabs[(i+1)%tabs.length];if(e.key==='ArrowLeft')n=tabs[(i-1+tabs.length)%tabs.length];if(e.key==='Home')n=tabs[0];if(e.key==='End')n=tabs[tabs.length-1];if(n){e.preventDefault();pick(n,true);}});
  });

  /* the door */
  var doorSec=document.querySelector('.door'),leaf=document.querySelector('.door-leaf');
  function setDoor(o){doorSec.classList.toggle('open',o);leaf.setAttribute('aria-pressed',o);leaf.setAttribute('aria-label',o?'Close the door':'Open the door');}
  leaf.addEventListener('click',function(){setDoor(!doorSec.classList.contains('open'))});
  document.querySelector('.knock').addEventListener('click',function(){
    if(doorSec.classList.contains('open')){setDoor(false);return;}
    if(reduce){setDoor(true);return;}
    leaf.classList.add('knocking');setTimeout(function(){leaf.classList.remove('knocking');setDoor(true);},1000);
  });
  if('IntersectionObserver' in window){var dio=new IntersectionObserver(function(es){if(es[0].isIntersecting){setTimeout(function(){setDoor(true)},900);dio.disconnect();}},{threshold:.6});dio.observe(leaf);}

  /* breathe with Skiby */
  var br=document.querySelector('.breath'),ball=br.querySelector('.ball'),btx=br.querySelector('.breath-txt'),bct=br.querySelector('.breath-count'),bT=[];
  function stopBreath(){bT.forEach(clearTimeout);bT=[];ball.classList.remove('in');br.hidden=true;document.querySelector('.breathe-btn').focus();}
  document.querySelector('.breathe-btn').addEventListener('click',function(){
    br.hidden=false;btx.textContent='Get comfy';bct.textContent='We will breathe together 4 times';
    br.querySelector('.breath-stop').focus();
    var t=1500;
    for(var r=1;r<=4;r++){(function(r){
      bT.push(setTimeout(function(){btx.textContent='Breathe in...';bct.textContent='Round '+r+' of 4';ball.classList.add('in');},t));
      bT.push(setTimeout(function(){btx.textContent='...and out';ball.classList.remove('in');},t+4000));
    })(r);t+=8000;}
    bT.push(setTimeout(function(){btx.textContent='You did it!';bct.textContent='Notice how your body feels now.';},t));
  });
  br.querySelector('.breath-stop').addEventListener('click',stopBreath);

  /* library filters */
  var grid=document.querySelector('.shelf-grid');
  document.querySelectorAll('.filters button').forEach(function(b){b.addEventListener('click',function(){
    var f=b.dataset.f;document.querySelectorAll('.filters button').forEach(function(x){x.setAttribute('aria-pressed',x===b)});
    grid.classList.toggle('filtered',f!=='all');
    grid.querySelectorAll('.item').forEach(function(it){it.classList.toggle('hide',f!=='all'&&it.dataset.type!==f);it.classList.add('in');});
  })});


  /* timeline */
  var TL=[
    {ic:'#i-book',h:'Psychology degree',p:'Bachelor of Science in Psychology from Universidad Santo Tomás in Colombia. The start of a path dedicated to children and families.'},
    {ic:'#i-house',h:'Clinical psychologist, 2011 to 2020',p:'Nearly a decade in Colombia with children and adolescents ages 5 to 18 and their families: mental health, trauma-informed intervention, emotional and behavioral needs.'},
    {ic:'#i-backpack',h:'School counseling begins',p:'In Massachusetts, a move into schools to be present in the everyday moments in between sessions, and to support children before small challenges grow.'},
    {ic:'#i-ribbon',h:'Master of Arts and license',p:'Master of Arts from Assumption University, with graduate preparation in school counseling and school adjustment counseling. Licensed Massachusetts School Adjustment Counselor.'},
    {ic:'#i-hola',h:'Mrs. Marcela today',p:'A multilingual School Adjustment Counselor, SEL educator and creator of Skiby, supporting students, families and educators in Spanish, English and Portuguese.'}
  ];
  var tl=document.querySelector('.tl'),tlBtns=[].slice.call(tl.querySelectorAll('.tl-stops button')),tlTxt=tl.querySelector('.tl-txt'),tlAuto=null;
  function tlGo(i,focus,user){
    if(user&&tlAuto){clearInterval(tlAuto);tlAuto=null;}
    i=Math.max(0,Math.min(TL.length-1,i));tl.dataset.i=i;
    tlBtns.forEach(function(b,k){b.setAttribute('aria-selected',String(k===i));b.tabIndex=k===i?0:-1;b.classList.toggle('done',k<i);});
    tl.querySelector('.tl-fill').style.width=(i/(TL.length-1)*100)+'%';
    tl.querySelector('.tl-prev').disabled=i===0;tl.querySelector('.tl-next').disabled=i===TL.length-1;
    document.getElementById('tl-panel').setAttribute('aria-labelledby','tl-'+i);
    if(focus)tlBtns[i].focus();
    tlTxt.classList.add('swapping');
    setTimeout(function(){document.getElementById('tl-h').textContent=TL[i].h;document.getElementById('tl-p').textContent=TL[i].p;document.getElementById('tl-ic').setAttribute('href',TL[i].ic);tlTxt.classList.remove('swapping');},reduce?0:200);
  }
  tlBtns.forEach(function(b,k){
    b.addEventListener('click',function(){tlGo(k,false,true)});
    b.addEventListener('keydown',function(e){var n=null;if(e.key==='ArrowRight')n=k+1;if(e.key==='ArrowLeft')n=k-1;if(e.key==='Home')n=0;if(e.key==='End')n=TL.length-1;if(n!==null){e.preventDefault();tlGo(n,true,true);}});
  });
  tl.querySelector('.tl-prev').addEventListener('click',function(){tlGo(+tl.dataset.i-1,false,true)});
  tl.querySelector('.tl-next').addEventListener('click',function(){tlGo(+tl.dataset.i+1,false,true)});
  tlGo(0);
  if(!reduce&&'IntersectionObserver' in window){var tio=new IntersectionObserver(function(es){if(es[0].isIntersecting&&!tlAuto&&tl.dataset.touched!=='1'){tl.dataset.touched='1';tlAuto=setInterval(function(){var n=+tl.dataset.i+1;if(n>=TL.length){clearInterval(tlAuto);tlAuto=null;return;}tlGo(n);},4500);tio.disconnect();}},{threshold:.5});tio.observe(tl);}

  window.addEventListener('scroll',function(){header.classList.toggle('scrolled',scrollY>10)},{passive:true});
  document.querySelector('.menu-btn').addEventListener('click',function(){var o=document.body.classList.toggle('menu-open');this.setAttribute('aria-expanded',o);this.setAttribute('aria-label',o?'Close menu':'Open menu');});

  /* weather check-in */
  var WX={
    sun:{h:'Sunny inside!',f:'You feel happy, calm or excited. That sunshine is worth sharing.',t:'Share your sunshine',d:'Tell someone one good thing about your day, or give a friend a compliment.'},
    cloud:{h:'A little cloudy',f:'Maybe you feel tired, bored or not quite sure. Clouds pass, and that is okay.',t:'Wake up your body',d:'Stretch tall like a tree, wiggle your fingers and toes, then take a sip of water.'},
    rain:{h:'Rainy feelings',f:'You might feel sad, lonely or disappointed. Rain helps things grow, and so do tears.',t:'Be kind to yourself',d:'Draw what the rain looks like, hug something soft, and tell a grown-up you trust how you feel.'},
    storm:{h:'Stormy inside',f:'You might feel angry or frustrated. Storms are loud, and they always calm down.',t:'Smell the flower, blow the candle',d:'Breathe in slowly like you are smelling a flower. Breathe out like you are blowing a candle. Do it five times.'},
    wind:{h:'Windy and wobbly',f:'Maybe you feel worried, nervous or jittery, like leaves blowing around.',t:'Find five things',list:['5 things you can see','4 things you can touch','3 things you can hear','2 things you can smell','1 thing you can taste']},
    rainbow:{h:'Rainbow after the rain',f:'You feel proud, brave or hopeful. You did something hard!',t:'Remember this feeling',d:'Draw a picture or write one sentence about what you did, so you can look back at it later.'}
  };
  var out=document.querySelector('.wx-out');
  document.querySelectorAll('.wx').forEach(function(b){
    b.addEventListener('click',function(){
      var k=b.dataset.wx,w=WX[k];
      document.querySelectorAll('.wx').forEach(function(x){x.setAttribute('aria-pressed',x===b)});
      out.classList.add('swap');
      setTimeout(function(){
        document.getElementById('wx-h').textContent=w.h;
        document.getElementById('wx-feel').textContent=w.f;
        var t=document.getElementById('wx-try'); t.innerHTML='';
        var bt=document.createElement('b');bt.textContent=w.t;t.appendChild(bt);
        if(w.list){var ul=document.createElement('ul');w.list.forEach(function(i){var li=document.createElement('li');li.textContent=i;ul.appendChild(li)});t.appendChild(ul);}else t.appendChild(document.createTextNode(w.d));
        out.classList.remove('swap');
      },reduce?0:220);
    });
  });
})();
